package org.example.aop;

public abstract class AbstractLibrary {
//    abstract public void getBook();
}
