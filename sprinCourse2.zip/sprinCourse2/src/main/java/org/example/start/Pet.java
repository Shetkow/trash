package org.example.start;

public interface Pet {
    void say();
}
